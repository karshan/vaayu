/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

namespace BinaryData
{
    extern const char*   jules_jpg;
    const int            jules_jpgSize = 24218;

    extern const char*   prefs_about_png;
    const int            prefs_about_pngSize = 1819;

    extern const char*   prefs_keys_png;
    const int            prefs_keys_pngSize = 3794;

    extern const char*   prefs_misc_png;
    const int            prefs_misc_pngSize = 6162;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}
